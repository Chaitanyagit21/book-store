import React from 'react';

const AuthorPanel = ({ author, selectedBook }) => {
  return (
    <div>
      <h2>Author Details</h2>
      <div>
        <img src={author.portraitImage} alt={author.name} />
        <h3>{author.name}</h3>
        <p>{author.biography}</p>
        <h4>Authored Books</h4>
        <ul>
          {author.authoredBooks.map((book) => (
            <li key={book.id}>{book.title}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AuthorPanel;

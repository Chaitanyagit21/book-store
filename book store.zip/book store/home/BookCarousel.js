import React from 'react';

const BookCarousel = ({ books, onBookClick }) => {
  return (
    <div>
      <h2>Book Carousel</h2>
      <div className="carousel">
        {books.map((book) => (
          <div key={book.id} onClick={() => onBookClick(book.id)}>
            <img src={book.coverImage} alt={book.title} />
            <p>{book.title}</p>
            <p>{book.author}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookCarousel;

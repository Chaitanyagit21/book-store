import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BookCarousel from './BookCarousel';
import AuthorPanel from './AuthorPanel';

const Home = () => {
  const [books, setBooks] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const [author, setAuthor] = useState(null);

  useEffect(() => {
    // Fetch books on component mount
    const fetchBooks = async () => {
      try {
        const response = await axios.get('/api/books');
        setBooks(response.data.books);
      } catch (error) {
        console.error('Error fetching books:', error);
      }
    };

    fetchBooks();
  }, []);

  const handleBookClick = async (bookId) => {
    // Fetch author details on book click
    try {
      const response = await axios.get(`/api/authors/${bookId}`);
      setAuthor(response.data.author);
    } catch (error) {
      console.error('Error fetching author details:', error);
    }

    // Set selected book for displaying details
    const selected = books.find((book) => book.id === bookId);
    setSelectedBook(selected);
  };

  return (
    <div>
      <BookCarousel books={books} onBookClick={handleBookClick} />
      {selectedBook && (
        <AuthorPanel author={author} selectedBook={selectedBook} />
      )}
    </div>
  );
};

export default Home;


